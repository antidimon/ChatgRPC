create function set_created_at() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.created_at := NOW();
    RETURN NEW;
END;
$$;

alter function set_created_at() owner to antidimon;

